# Assignment 1, Exercise 1

from math import pi

# Radius
# Receives a value from the keyboard and stores it in r
r = float(input("Input the radius of the circle : "))

# Write code here!
area = pi * r ** 2
print(f'The area of the circle with radius {float(r)} is {area}')
